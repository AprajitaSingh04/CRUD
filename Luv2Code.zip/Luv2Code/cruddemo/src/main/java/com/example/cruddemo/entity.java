package com.example.cruddemo;

public class entity {
}
