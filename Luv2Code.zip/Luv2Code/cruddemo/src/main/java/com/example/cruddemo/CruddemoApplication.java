package com.example.cruddemo;

import com.example.cruddemo.dao.studentDAO;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CruddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruddemoApplication.class, args);
	}


	// Crud repo  --> Java Lambda Expression
	/*@Bean
	public CommandLineRunner commandLineRunner (String[] args) {

		return CommandLineRunner -> {
			System.out.println(" CommandLineApp...!!!");
		};

	}*/


	// studentDAO StudentDAO

	@Bean
	public CommandLineRunner commandLineRunner (studentDAO StudentDAO) {

		return CommandLineRunner -> {
			// createStudent (StudentDAO);
			// createMultipleStudents (StudentDAO);
			readstudent (StudentDAO);
		};

	}

	private void readstudent(studentDAO studentDAO) {

		 // create the student object

				System.out.println("creating new student object....");

				student tempstudent = new student ( "Daffy",  "Duck", "daffyduck@gmail.com");


				// save the student object

				System.out.println("Saving new student object....");
				studentDAO.save(tempstudent);

				// display id of the saved objects

		        int theId = tempstudent.getId();
				System.out.println("Saved student. Generated id: + theId");



		        // retrieve student based on the id: primary key

				System.out.println("Retrieving student with id: + theId");
				student mystudent = studentDAO.findById(theId);


	         	// display the student object
				System.out.println("Found the student: " + mystudent);
	}

	private void createMultipleStudents(studentDAO studentDAO) {

		// create multiple students

		System.out.println("creating 3 student objects....");

		student tempstudent1 = new student ( "John",  "Doe", "john@gmail.com");
		student tempstudent2 = new student ( "Mary",  "Public", "mary@gmail.com");
		student tempstudent3 = new student ( "Bonita",  "Applebum", "bonita@gmail.com");



		// save the students objects
		System.out.println("Saving new student object....");
		studentDAO.save(tempstudent1);
		studentDAO.save(tempstudent2);
		studentDAO.save(tempstudent3);



	}

	private void createStudent (studentDAO StudentDAO){
	 // create the student object

		System.out.println("creating new student object....");

		student tempstudent = new student ( "Paul",  "Doe", "paul@gmail.com");


		// save the student object

		System.out.println("Saving new student object....");
		StudentDAO.save(tempstudent);


		// display the student object
		System.out.println("Saved student.generated id: " + tempstudent.getId());


	}
}
