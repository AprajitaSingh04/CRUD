package com.example.cruddemo.dao;

import com.example.cruddemo.student;

public interface studentDAO {

    void save (student thestudent);

    student findById (Integer id);



}
