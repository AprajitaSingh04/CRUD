package com.example.cruddemo.dao;

import com.example.cruddemo.student;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;


@Repository
public class studentDAOImpl implements studentDAO{


    // define field for entity manager

    private EntityManager entityManager;


    // inject entity manager using constructor injection


    public studentDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    // implement save method
    @Override
    @Transactional
    public void save (student thestudent){

        entityManager.persist(thestudent);

    }

    @Override
    public student findById(Integer id) {
        return entityManager.find(student.class, id);
    }


}
